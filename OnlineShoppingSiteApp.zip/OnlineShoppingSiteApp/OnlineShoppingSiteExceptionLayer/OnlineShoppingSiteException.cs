﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingSiteExceptionLayer
{
    /// <summary>
    /// Online Shopping Site Exception Class
    /// </summary>
    public class OnlineShoppingSiteException:Exception
    {
        /// <summary>
        /// This Method Handles All The Exceptions
        /// </summary>
        /// <param name="errMsg"></param>
        public OnlineShoppingSiteException(string errMsg) : base(errMsg) 
        { 

        }
    }
}
