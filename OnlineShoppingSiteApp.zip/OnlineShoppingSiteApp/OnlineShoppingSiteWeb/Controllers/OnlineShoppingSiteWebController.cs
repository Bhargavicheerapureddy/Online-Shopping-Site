﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingSiteEntityLayer;//References For Entities
using OnlineShoppingSiteBusinessLayer;//References For Business
using OnlineShoppingSiteExceptionLayer;//References For Exception

namespace OnlineShoppingSiteWeb.Controllers
{
    public class OnlineShoppingSiteWebController : ApiController
    {
        [Route("api/OnlineShoppingSiteWeb/GetProductsByName/{Name}")]
        /// <summary>
        /// This Method Will Display/Retrive All the Products In the Home Page
        /// </summary>
        /// <param name="Name">Names of Products are Passed</param>
        /// <returns>It Returns the Products list present in the Selected Category </returns>
        public HttpResponseMessage GetProductsByName(string Name)
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Sorry.Your ProductName is not in List");
            //Try Block Incase if Code Throws An Expection
            try
            {
                //Create Object For Buniness Layer
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var lst = bll.GetProductsByName(Name);
                httpResponseMessage = Request.CreateResponse<List<Product>>(lst);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex) 
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/OnlineShoppingSiteWeb/GetProductsByCategory/{Name}")]
        /// <summary>
        /// This Method Will Display/Retrive All Products By CategoryName 
        /// </summary>
        /// <param name="Name"> Categorie Names are Passed</param>
        /// <returns>It Returns the Products list present in Selected Category </returns>
        public HttpResponseMessage GetProductsByCategory(string Name)
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Sorry.Your Product is not in The Category");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var lst = bll.GetProductsByCategory(Name);
                httpResponseMessage = Request.CreateResponse<List<Product>>(lst);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        public HttpResponseMessage Get() 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Get Your Item In List");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var cat = bll.GetAllCategories();
                httpResponseMessage = Request.CreateResponse<List<Category>>(cat);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/OnlineShoppingSiteWeb/GetProductDetailsById/{id}")]
        /// <summary>
        /// This Method Will Display/Retrive All ProductsDetails By its ProductID
        /// </summary>
        /// <param name="id">By using this id We Can Get ProductDeatils</param>
        /// <returns>It Returns Product Details </returns>
        public HttpResponseMessage GetProductDetailsById(int id)
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Sorry.Your Productid is not in List");
            //Try Block Incase if Code Throws An Expection
            try
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var lst = bll.GetProductDetailsById(id);
                httpResponseMessage = Request.CreateResponse<Product>(lst);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }

        [Route("api/OnlineShoppingSiteWeb/AddToCart/")]
        /// <summary>
        /// By Using This Method We can Add Items to The Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can add item to the cart</param>
        public HttpResponseMessage Post([FromBody] List<CartItems> cartList) 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Your Item is Added To the Cart");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                bll.AddToCart(cartList);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/OnlineShoppingSiteWeb/PostToCart/")]
        /// <summary>
        /// By using This Method We can Post Items to the Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can Post items to the cart</param>
        public HttpResponseMessage PostToCart([FromBody] CartItems cartList)
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Your Item is Posted To the Cart");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                bll.PostToCart(cartList);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/OnlineShoppingSiteWeb/GetListFromCart/")]
        /// <summary>
        /// By Using this Method We Can Get List from The Cart
        /// </summary>
        /// <returns>It Returns List From Cart</returns>
        public HttpResponseMessage GetListFromCart() 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/ Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "View Your List");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var lst = bll.GetListFromCart();
                httpResponseMessage = Request.CreateResponse<List<CartItems>>(lst);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        /// <summary>
        /// By Using This Method We can Delete Item From Cart
        /// </summary>
        /// <param name="id">By Using this Id we can Delete That Item  </param>
        public HttpResponseMessage Delete(int id) 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/ Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK,"Your Item Deleted");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                bll.DeleteItemFromCart(id);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/OnlineShoppingSiteWeb/PutItemsById/{id}")]
        /// <summary>
        /// By Using this Method We can UPDATE the Quantity of the Selected Product
        /// </summary>
        /// <param name="cartlist">By using this cartList we can Update item Quantity</param>
        /// <param name="id">By Using this Id we can Update That Quantity</param>
        /// <returns>It Returns Product Quantity</returns>
        public HttpResponseMessage PutItemsById([FromBody] CartItems cartlist, int id) 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/ Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Item Quantity Updated");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                bll.UpdateItemsById(cartlist);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;



        }
        /// <summary>
        /// By Using this Method We can Get Product Details From DataBase
        /// </summary>
        /// <param name="id">By using this id we can GetProduct Details of the Item  </param>
        /// <returns>It Returns the cartList based on its Productid</returns>
        public HttpResponseMessage GetProductItemById(int id) 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Sorry.Your Productid is not in List");
            //Try Block Incase if Code Throws An Expection 
            try
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var lst = bll.GetProductItemById(id);
                httpResponseMessage = Request.CreateResponse<CartItems>(lst);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
    }
}
