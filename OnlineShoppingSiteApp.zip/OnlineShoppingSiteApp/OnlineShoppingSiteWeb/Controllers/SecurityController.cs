﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingSiteEntityLayer;//References For Entities
using OnlineShoppingSiteBusinessLayer;//References For Business Layer
using OnlineShoppingSiteExceptionLayer;//References For Exceptions

namespace OnlineShoppingSiteWeb.Controllers
{
    public class SecurityController : ApiController
    {
        [Route("api/Security/GetUserName/{name}")]
        /// <summary>
        /// By Using this Method We can Get UserName.
        /// </summary>
        /// <param name="name">UserName was Passed</param>
        /// <returns>It Return UserName </returns>
        public HttpResponseMessage GetUserName(string name) 
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Get UserName");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var username = bll.GetUserName(name);
                httpResponseMessage = Request.CreateResponse<Login>(username);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
        [Route("api/Security/GetPassword/{pwd}")]
        /// <summary>
        /// By Using This Method We can Get Password.
        /// </summary>
        /// <param name="pwd">Password was Passed</param>
        /// <returns>Return Password</returns>
        public HttpResponseMessage GetPassword(string pwd)
        {
            //HttpResponseMessage Works With HTTP Protocal to Return The Data with Status/Error
            HttpResponseMessage httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.OK, "Get Password");
            //Try Block Incase if Code Throws An Expection
            try 
            {
                OnlineShoppingSiteBusiness bll = new OnlineShoppingSiteBusiness();
                var pswd = bll.GetPassword(pwd);
                httpResponseMessage = Request.CreateResponse<Login>(pswd);
            }
            //If  OnlineshoppingSite Expection Occurs it will Handle Here
            catch (OnlineShoppingSiteException ex)
            {
                //If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            //If any other Expections that are not handled in Previous Catch Block It will be Handle Here
            catch (Exception ex)
            {
                ////If the Product Dose not Exist it will Return the Status
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.NotFound, ex.Message);
            }
            //Returns httpResponseMessage
            return httpResponseMessage;
        }
    }
}
