﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingSiteEntityLayer;//Reference For Entities
using OnlineShoppingSiteExceptionLayer;//Reference For Exceptions
using System.Data;
using System.Data.SqlClient;//For Ado.Net Classes Connection,Command

namespace OnlineShoppingSiteDataAccessLayer
{
    public class OnlineShoppingSiteDataAccess
    {
        SqlConnection con;
        SqlCommand cmd;
        public OnlineShoppingSiteDataAccess()
        {
            //Configure Connection Object
            con = new SqlConnection();
            con.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=HCLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        }
        /// <summary>
        /// This Method Will Display/Retrive All the Products In the Home Page
        /// </summary>
        /// <param name="productName">Names of Products are Passed</param>
        /// <returns>It Returns the Products list present in the Selected Category </returns>
        public List<Product> GetProductsByName(string productName)
        {
            List<Product> products = new List<Product>();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure command for GetProducts By Name
                cmd = new SqlCommand();
                cmd.CommandText = "select id,pname,picture,price from product where pname like @name";
                //Supply values to the Parameters of the Command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@name", "%" + productName + "%");
                //Specify the Type of Command
                cmd.CommandType = CommandType.Text;
                //Attach Connection with the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute The Command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the Records form Data Reader and add them to the Collection
                while (sdr.Read())
                {
                    Product pro = new Product
                    {
                        ProductId = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    products.Add(pro);
                }
                sdr.Close();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Close Connection
                con.Close();
            }
            //Return all records using Collection
            return products;
        }
        /// <summary>
        /// This Method Will Display/Retrive All Products By CategoryName 
        /// </summary>
        /// <param name="categoryName"> Categorie Names are Passed</param>
        /// <returns>It Returns the Products list present in Selected Category </returns>
        public List<Product> GetProductsByCategory(string categoryName)
        {
            List<Product> products = new List<Product>();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure command for GetProductbyCategory
                cmd = new SqlCommand();
                cmd.CommandText = "select p.id,p.pname,p.picture,p.price from product as p join prod_category as c " +
                                 " on p.categoryid=c.categoryid and c.categoryname like @cn";
                //Supply values to the Parameters of the Command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@cn", "%" + categoryName + "%");
                //Specify the Type of Command
                cmd.CommandType = CommandType.Text;
                //Attach Connection with the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excutes the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the Records form Data Reader and add them to the Collection
                while (sdr.Read())
                {
                    Product pro = new Product
                    {
                        ProductId = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    products.Add(pro);
                }
                sdr.Close();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Close Connection
                con.Close();
            }
            //Return all records using Collection
            return products;
        }
        /// <summary>
        /// This Method Will Display/Retrive All The Categories in the HomePage
        /// </summary>
        /// <returns>It Return all The Categories </returns>
        public List<Category> GetAllCategories()
        {
            List<Category> lstcate = new List<Category>();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure command for Get All Categories
                cmd = new SqlCommand();
                cmd.CommandText = "select categoryid,categoryname from prod_category";
                //Supply values to the Parameters of the Command
                cmd.CommandType = CommandType.Text;
                //Attach Connection with the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excutes the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the Records form Data Reader and add them to the Collection
                while (sdr.Read())
                {
                    Category category = new Category
                    {
                        CategoryId = (int)sdr[0],
                        CategoryName = sdr[1].ToString()
                    };
                }
                sdr.Close();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all records using Collection
            return lstcate;
        }
        /// <summary>
        /// This Method Will Display/Retrive All ProductsDetails By its ProductID
        /// </summary>
        /// <param name="id">By using this id We Can Get ProductDeatils</param>
        /// <returns>It Returns Product Details </returns>
        public Product GetProductDetailsById(int id)
        {
            Product product = null;
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure command for GetProduct statement
                cmd = new SqlCommand();
                cmd.CommandText = "select id,pname,picture,description,price,quantity from product where id=@id";
                //Supply values to the Parameters of the Command
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", id);
                //Supply values to the Parameters of the Command
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach Connection with the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the Records form Data Reader and add them to the Collection
                if (sdr.Read())
                {
                    product = new Product();
                    product.ProductId = (int)sdr[0];
                    product.ProductName = sdr[1].ToString();
                    product.Picture = sdr[2].ToString();
                    product.Description = sdr[3].ToString();
                    product.Price = Convert.ToDouble(sdr[4]);
                    product.Quantity = (int)sdr[5];
                }
                else
                {
                    throw new Exception("Product DoesNot Exixt");
                }
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all records using Collection
            return product;
        }
        /// <summary>
        /// By Using This Method We can Add Items to The Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can add item to the cart</param>
        public void AddToCart(List<CartItems> cartList)
        {
            //Initialize Roweffected Variable
            int roweffected;
            //Try Block,incase if code throws an Exception
            try
            {
                //Open Connection
                con.Open();
                //Foreach Loop for Displaying the List in Cart
                foreach (var items in cartList)
                {
                    //Configure Command for Add to Cart
                    cmd = new SqlCommand();
                    //Query for Inserting the Product Details into DataBase
                    cmd.CommandText = "insert into cartItems(id,pname,picture,price,description,quantity) values(@id,@pn,@pic,@pr,@des,@Qty)";
                    //Remove the Garbage Values
                    cmd.Parameters.Clear();
                    //Add the values to the Cart Items
                    cmd.Parameters.AddWithValue("@id", items.ProductID);
                    cmd.Parameters.AddWithValue("@pn", items.ProductName);
                    cmd.Parameters.AddWithValue("@pic", items.Picture);
                    cmd.Parameters.AddWithValue("@pr", items.Price);
                    cmd.Parameters.AddWithValue("@des", items.Description);
                    cmd.Parameters.AddWithValue("@Qty", items.Quantity);
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Configure Connections
                    cmd.Connection = con;
                    //Excutes non Query
                    roweffected = cmd.ExecuteNonQuery();
                    //If condition is true data can not be Inserted
                    if (roweffected == 0)
                    {
                        //Throws Exception
                        throw new Exception("Could not Add Data");
                    }
                }
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException (ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally 
            {
                //Closing The Connection
                con.Close();
            }
        }
        /// <summary>
        /// By using This Method We can Post Items to the Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can Post items to the cart</param>
        public void PostToCart(CartItems cartList)
        {
            //Initialize Roweffected Variable
            int roweffected;
            //Try Block,incase if code throws an Exception
            try
            {
                    //Configure Command for Post To Cart
                    cmd = new SqlCommand();
                    //Query for Inserting the Product Details into DataBase
                    cmd.CommandText = "insert into cartItems(id,pname,picture,price,description,quantity) values(@id,@pn,@pic,@pr,@des,@Qty)";
                    //Remove the Garbage Values
                    cmd.Parameters.Clear();
                    //Adding Parameters with values to the DataBase
                    cmd.Parameters.AddWithValue("@id",  cartList.ProductID);
                    cmd.Parameters.AddWithValue("@pn",  cartList.ProductName);
                    cmd.Parameters.AddWithValue("@pic", cartList.Picture);
                    cmd.Parameters.AddWithValue("@pr",  cartList.Price);
                    cmd.Parameters.AddWithValue("@des", cartList.Description);
                    cmd.Parameters.AddWithValue("@Qty", cartList.Quantity);
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Configure Connections
                    cmd.Connection = con;
                    //Excutes non Query
                    roweffected = cmd.ExecuteNonQuery();
                    //If condition is true data can not be Inserted
                    if (roweffected == 0)
                    {
                        throw new Exception("Could not Add Data");
                    }
                   //Open Connection
                   con.Open();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing The Connection
                con.Close();
            }
        }
        /// <summary>
        /// By Using this Method We Can Get List from The Cart
        /// </summary>
        /// <returns>It Returns List From Cart</returns>
        public List<CartItems> GetListFromCart() 
        {
            List<CartItems> lst = new List<CartItems>();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for GetList From Cart
                cmd = new SqlCommand();
                cmd.CommandText = "select id,pname,picture,price,description from cartItems";
                //Specify the Type of Command
                cmd.CommandType = CommandType.Text;
                //Attach the connection with the command 
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from DataReader and add them to the Collection
                while (sdr.Read())
                {
                    CartItems cart = new CartItems
                    {
                        ProductID = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Picture = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3]),
                        Description = sdr[4].ToString()
                    };
                    lst.Add(cart);
                }
                sdr.Close();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all the records using Collection
            return lst;
        }
        /// <summary>
        /// By Using This Method We can Delete Item From Cart
        /// </summary>
        /// <param name="id">By Using this Id we can Delete That Item  </param>
        public void DeleteItemFromCart(int id) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for Delete 
                cmd = new SqlCommand();
                cmd.CommandText = "delete from cartItems where id=@id";
                //Pass Values to the Parameters
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = CommandType.Text;
                //Open Connection
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                //Close Connection
                con.Close();
                if (recordsAffected == 0)
                {
                    throw new Exception("Could not Delete");
                }
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex) 
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
        }
        /// <summary>
        /// By Using this Method We can UPDATE the Quantity of the Selected Product
        /// </summary>
        /// <param name="cartList">By using this cartList we can Update item Quantity </param>
        public void UpdateItemsById(CartItems cartList) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for UpdateItems By id
                cmd = new SqlCommand();
                cmd.CommandText = "update cartItems set quantity=@qty where id=@id";
                //Attach Connection to Comamnd
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                //Pass values to the Parameters
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", cartList.ProductID);
                cmd.Parameters.AddWithValue("@qty", cartList.Quantity);
                //Open Connection
                con.Open();
                int recordAffected = cmd.ExecuteNonQuery();
                if (recordAffected == cmd.ExecuteNonQuery())
                {
                    throw new Exception("id does not exist");
                }
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
        }
        /// <summary>
        /// By Using this Method We can Get Product Details From DataBase
        /// </summary>
        /// <param name="id">By using this id we can GetProduct Details of the Item  </param>
        /// <returns>It Returns the cartList based on its Productid</returns>
        public CartItems GetProductItemById(int id) 
        {
            CartItems cartList = null;
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for GetProductItem By id
                cmd = new SqlCommand();
                cmd.CommandText = "select id,picture,price,description,quantity from cartItems where id=@id";
                //Pass values to the Parameters
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = System.Data.CommandType.Text;
                //Attach connection to the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    cartList = new CartItems();
                    cartList.ProductID = (int)sdr[0];
                    cartList.ProductName = sdr[1].ToString();
                    cartList.Picture = sdr[2].ToString();
                    cartList.Price = Convert.ToDouble(sdr[3]);
                    cartList.Description = sdr[4].ToString();
                    cartList.Quantity = (int)sdr[5];
                }
                else
                {
                    throw new Exception("Product dose not Exist");
                }
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex) 
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all records using Collection
            return cartList;
        }
        /// <summary>
        /// By Using this Method We can Get UserName.
        /// </summary>
        /// <param name="name">UserName was Passed</param>
        /// <returns>It Return UserName </returns>
        public Login GetUserName(string name) 
        {
            Login login = new Login();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for GetUserName
                cmd = new SqlCommand();
                cmd.CommandText = "select username from UserDetails where username = @un";
                //Pass values to the Parameters
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", name);
                cmd.CommandType = CommandType.Text;
                //Attach connection to the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.UserName = sdr[0].ToString();
                }
                sdr.Close();
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException("Some DataBase error Occured: "+ ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException("Some DataBase error Occured: " + ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all records using Collection
            return login;
        }
        /// <summary>
        /// By Using This Method We can Get Password.
        /// </summary>
        /// <param name="pwd">Password was Passed</param>
        /// <returns>Return Password</returns>
        public Login GetPassword(string pwd) 
        {
            Login login = new Login();
            //Try Block,incase if code throws an Exception
            try
            {
                //Configure Command for GetPassword
                cmd = new SqlCommand();
                cmd.CommandText = "select password from UserDetails where password = @pwd";
                //Pass values to the Parameters
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@pwd", pwd);
                cmd.CommandType = CommandType.Text;
                //Attach connection to the Command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Excute the Command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    login.Password = sdr[0].ToString();
                }
                sdr.Close();

            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (SqlException ex)
            {
                throw new OnlineShoppingSiteException("Some DataBase Error Occured: " + ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException("Some DataBase Error Occured: " + ex.Message);
            }
            //Finally block Executes even Exception occurs or not Occurs
            finally
            {
                //Closing Connection
                con.Close();
            }
            //Return all records using Collection
            return login;
        }

    }
}
