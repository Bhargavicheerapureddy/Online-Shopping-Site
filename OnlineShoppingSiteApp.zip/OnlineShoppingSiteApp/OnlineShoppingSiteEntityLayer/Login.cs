﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingSiteEntityLayer
{
    /// <summary>
    /// Login Class
    /// </summary>
    public class Login
    {   
        /// <summary>
        /// EmailId
        /// </summary>
        public string EmailId { get; set; }
        /// <summary>
        /// UserName
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Confirm Password
        /// </summary>
        public string ConfirmPassword { get; set; }
    }
}
