﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingSiteApp.Models
{
    /// <summary>
    /// Cart Items Class
    /// </summary>
    public class CartItems
    {
        /// <summary>
        /// Product Id
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Picture
        /// </summary>
        public string Picture { get; set; }
        /// <summary>
        /// Price
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Quantity
        /// </summary>
        public int Quantity { get; set; }
        /// <summary>
        /// Display Description
        /// </summary>
        /// <returns>It Return Data</returns>
        public string DisplayDescription()
        {
            string data = null;
            string[] cols = Description.Split(',');
            foreach (var item in cols)
            {
                string colName, colValue;
                string[] col = item.Split(':');
                colName = col[0];
                colValue = col[1];
                data += "<b>" + colName + "</b>" + ":" + colValue + "<br/>";
            }
            return data;

        }
    }
}