﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingSiteApp.Models
{
    /// <summary>
    /// Category Class
    /// </summary>
    public class Category
    {
        /// <summary>
        /// Category Id
        /// </summary>
        public int CategoryId { get; set; }
        /// <summary>
        /// CAtegory Name
        /// </summary>
        public string CategoryName { get; set; }
    }
}