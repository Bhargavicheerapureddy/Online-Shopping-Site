﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;//For DataAnnotations
using System.Linq;
using System.Web;

namespace OnlineShoppingSiteApp.Models
{
    /// <summary>
    /// Login Class
    /// </summary>
    public class Login
    {
        [Required(ErrorMessage = "Enter EmailId")]
        /// <summary>
        /// EmailId
        /// </summary>
        public string EmailId { get; set; }
        [Required]
        [StringLength(15,MinimumLength =8,ErrorMessage ="Name must be Between 8 to 15 Characters")]
        [RegularExpression("[aA-zZ]*",ErrorMessage ="Only Alphabets A-Z are Accepted For UserName")]
        /// <summary>
        /// UserName
        /// </summary>
        public string UserName { get; set; }
        [Required]
        [RegularExpression(@"\d{8,10}",ErrorMessage ="Password Must be only 8 Characters")]
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        [Required]
        [RegularExpression(@"\d{8,10}", ErrorMessage = "Confirm Password Must be only 8 Characters")]
        /// <summary>
        /// Confirm Password
        /// </summary>
        public string ConfirmPassword { get; set; }
    }
}