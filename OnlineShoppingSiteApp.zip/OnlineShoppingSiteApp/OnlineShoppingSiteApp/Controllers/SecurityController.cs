﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;
using OnlineShoppingSiteApp.Models;//For Models

namespace OnlineShoppingSiteApp.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login)
        {
            ////Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");
            using (var client = new HttpClient())
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var uname = client.GetStringAsync("Security/GetUserName/" + login.UserName).Result;
                var name = JsonConvert.DeserializeObject<Login>(uname);
                string username = name.UserName;
                var pswd = client.GetStringAsync("Security/GetPassword/" + login.Password).Result;
                var pwd = JsonConvert.DeserializeObject<Login>(pswd);
                string password = pwd.Password;
                if ((login.UserName.Equals(username)) && (login.Password.Equals(password)))
                {
                    FormsAuthentication.SetAuthCookie(login.UserName, false);
                    var returnUrl = Request.Form["returnUrl"];
                    return Redirect("returnUrl");
                }
                else
                {
                    ModelState.AddModelError("errMsg", "UserName & Password are Invalid,Please try with Another Credentials");
                }
                var returnUrl1 = Request.QueryString.Get("ReturnUrl");
                ViewData.Add("returnUrl", returnUrl1);
                return View();
            }
        }
        [HttpPost]
        public ActionResult Logout() 
        {
            FormsAuthentication.SignOut();
            return View();
        }
    }
}