﻿using Newtonsoft.Json;
using OnlineShoppingSiteApp.Models;//For Models
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace OnlineShoppingSiteApp.Controllers
{
    public class OnlineShoppingSiteMvcController : Controller
    {
        // GET: OnlineShoppingSiteMvc
        [HttpGet]
        public ActionResult HomePage()
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");
            using (var client = new HttpClient())
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShoppingSiteWeb").Result;
                var lst = JsonConvert.DeserializeObject<List<Category>>(result);
                return View(lst);
            }
        }
        [HttpPost]
        public ActionResult DisplayProductsByName(string Name)
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShoppingSiteWeb/GetProductsByName/" + Name).Result;
                var lst = JsonConvert.DeserializeObject<List<Product>>(result);

                return View(lst);
            }
        }
        [HttpGet]
        public ActionResult DisplayProductsByCategory(string Name) 
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");

            using (var client = new HttpClient())
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShoppingSiteWeb/GetProductsByCategory/" + Name).Result;
                var lst = JsonConvert.DeserializeObject<List<Product>>(result);

                return View(lst);
            }
        }
        [HttpGet]
        public ActionResult DisplayProductDetailsById(int id)
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShoppingSiteWeb/GetProductDetailsById/" + id).Result;
                var lst = JsonConvert.DeserializeObject<Product>(result);

                return View(lst);
            }
        }
        [HttpGet]
        public ActionResult AddToCart() 
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddToCart(CartItems item) 
        {
            item.Quantity = 1;
            if (Session["cart"] == null)
            {
                var cartList = new List<CartItems>();
                cartList.Add(item);
                Session.Add("cart", cartList);
            }
            else 
            {
                var cartList = (List<CartItems>)Session["cart"];
                cartList.Add(item);
                Session.Add("cart", cartList);
            }
            return RedirectToAction("HomePage");
        }
        public ActionResult DisplayCart() 
        {
            var cartLst = (List<CartItems>)Session["cart"];
            Session.Add("cartList", cartLst);
            return View(cartLst);
        }
        public ActionResult PostToCart()
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");
            var cartList = (List<CartItems>)Session["cart"];
            using (var client = new HttpClient())
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync<List<CartItems>>("OnlineShoppingSiteWeb/AddToCart", cartList).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Product List Posted Sucessfully..!!!");
                }
                else
                {
                    ViewData.Add("msg", "Not Sucessful..!!!");
                }
            }
            return View(cartList);
        }
        public ActionResult GetListFromCart() 
        {
            Uri uri = new Uri("http://localhost:52688/api/");

            using (var client = new HttpClient()) 
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShoppingSiteWeb/GetListFromCart/").Result;
                var lst = JsonConvert.DeserializeObject<List<CartItems>>(result);
                return View(lst);
            }
        }
        public ActionResult Delete(int id)
        {
            var cartList = (List<CartItems>)Session["cart"];
            var product = cartList.Where(o => o.ProductID == id).FirstOrDefault();
            cartList.Remove(product);
            Session["cart"] = cartList;
            return RedirectToAction("HomePage");
        }
        public ActionResult DeleteYourOrder(int id) 
        {
            //Local Host Connection of Api
            Uri uri = new Uri("http://localhost:52688/api/");

            using (var client = new HttpClient())
            {
                //Sets The Base Address Defines The Uri Path
                client.BaseAddress = uri;
                var result = client.DeleteAsync("OnlineShoppingSiteWeb" +id).Result;

                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Record Deleted Sucessfully..!!");
                }
                else 
                {
                    ViewData.Add("msg", " Could not Delete Record ,Some Error May Occur");
                }
                return RedirectToAction("HomePage");
                
            }
        }
        [HttpGet]
        public ActionResult UpdateCartById(int id) 
        {
            var cartItemsList = (List<CartItems>)Session["cart"];
            var cartItem = cartItemsList.Where(o => o.ProductID == id).FirstOrDefault();
            return View(cartItem);
        }
        [HttpPost]
        public ActionResult UpdateCartById(CartItems cartList) 
        {
            var cartItemsList = (List<CartItems>)Session["cart"];
            var cartItem = cartItemsList.Where(o => o.ProductID == cartList.ProductID).FirstOrDefault();
            cartItem.Quantity = cartList.Quantity;
            Session["cart"] = cartItemsList;
            return RedirectToAction("DisplayCart");
        }
        [HttpGet]
        [Authorize]
        public ActionResult PlaceOrder() 
        {
            var cartList = (List<CartItems>)Session["cart"];
            cartList.Clear();
            Session["cart"] = cartList;
            return View();
        }
    }
}