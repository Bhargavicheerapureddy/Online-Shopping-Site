﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingSiteEntityLayer;//References for Entities

namespace OnlineShoppingSiteBusinessLayer
{
    /// <summary>
    /// Interface For Online Shopping Site Business Layer
    /// </summary>
    interface IBusiness
    {
        /// <summary>
        /// This Method Will Display/Retrive All the Products In the Home Page
        /// </summary>
        /// <param name="productName">Names of Products are Passed</param>
        /// <returns>It Returns the Products list present in the Selected Category</returns>
        List<Product> GetProductsByName(string productName);
        /// <summary>
        /// This Method Will Display/Retrive All Products By CategoryName 
        /// </summary>
        /// <param name="categoryName">Category Names are Passed </param>
        /// <returns>It Returns the Products list present in Selected Category</returns>
        List<Product> GetProductsByCategory(string categoryName);
        /// <summary>
        /// This Method Will Display/Retrive All The Categories in the HomePage
        /// </summary>
        /// <returns>It Return all The Categories</returns>
        List<Product> GetAllCategories();
        /// <summary>
        /// This Method Will Display/Retrive All ProductsDetails By its ProductID
        /// </summary>
        /// <param name="id">By Using this id We can Display The ProductDetails </param>
        /// <returns>It Returns the Product Details</returns>
        Product GetProductDetailsById(int id);
        /// <summary>
        /// By Using This Method We can Add Items to The Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can add item to the cart</param>
        void AddToCart(List<CartItems> cartList);
        /// <summary>
        /// By using This Method We can Post Items to the Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can Post items to the cart</param>
        void PostToCart(CartItems cartList);
        /// <summary>
        /// By Using this Method We Can Get List from The Cart
        /// </summary>
        /// <returns>It Returns List From Cart</returns>
        List<CartItems> GetListFromCart();
        /// <summary>
        /// By Using This Method We can Delete Item From Cart
        /// </summary>
        /// <param name="id">By Using this Id we can Delete That Item  </param>
        void DeleteItemFromCart(int id);
        /// <summary>
        /// By Using this Method We can UPDATE the Quantity of the Selected Product
        /// </summary>
        /// <param name="cartList">By using this cartList we can Update item Quantity </param>
        void UpdateItemsById(CartItems cartList);
        /// <summary>
        /// By Using this Method We can Get Product Details From DataBase
        /// </summary>
        /// <param name="id">By using this id we can GetProduct Details of the Item  </param>
        /// <returns>It Returns the cartList based on its Productid</returns>
        CartItems GetProductItemById(int id);
        /// <summary>
        /// By Using this Method We can Get UserName.
        /// </summary>
        /// <param name="name">UserName was Passed</param>
        /// <returns>It Return UserName </returns>
        Login GetUserName(string name);
        /// <summary>
        /// By Using This Method We can Get Password.
        /// </summary>
        /// <param name="pwd">Password was Passed</param>
        /// <returns>Return Password</returns>
        Login GetPassword(string pwd);
    }
}
