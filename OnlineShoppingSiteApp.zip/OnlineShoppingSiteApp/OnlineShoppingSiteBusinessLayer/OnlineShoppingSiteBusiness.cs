﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingSiteEntityLayer;//References for Entities
using OnlineShoppingSiteDataAccessLayer;//References for DataAccess
using OnlineShoppingSiteExceptionLayer;//Refrences for Exception

namespace OnlineShoppingSiteBusinessLayer
{
    public class OnlineShoppingSiteBusiness
    {
        /// <summary>
        /// This Method Will Display/Retrive All the Products In the Home Page
        /// </summary>
        /// <param name="productName">Names of Products are Passed</param>
        /// <returns>It Returns the Products list present in the Selected Category </returns>
        public List<Product> GetProductsByName(string productName)
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var lst = dal.GetProductsByName(productName);
                return lst;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }

        }
        /// <summary>
        /// This Method Will Display/Retrive All Products By CategoryName 
        /// </summary>
        /// <param name="categoryName"> Categorie Names are Passed</param>
        /// <returns>It Returns the Products list present in Selected Category </returns>
        public List<Product> GetProductsByCategory(string categoryName) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var lst = dal.GetProductsByCategory(categoryName);
                return lst;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// This Method Will Display/Retrive All The Categories in the HomePage
        /// </summary>
        /// <returns>It Return all The Categories </returns>
        public List<Category> GetAllCategories()
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var lst = dal.GetAllCategories();
                return lst;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// This Method Will Display/Retrive All ProductsDetails By its ProductID
        /// </summary>
        /// <param name="id">By using this id We Can Get ProductDeatils</param>
        /// <returns>It Returns Product Details </returns>
        public Product GetProductDetailsById(int id) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var lst = dal.GetProductDetailsById(id);
                return lst;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }

        }
        /// <summary>
        /// By Using This Method We can Add Items to The Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can add item to the cart</param>
        public void AddToCart(List<CartItems> cartList) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                dal.AddToCart(cartList);
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex) 
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By using This Method We can Post Items to the Cart
        /// </summary>
        /// <param name="cartList">By using this cartList we can Post items to the cart</param>
        public void PostToCart(CartItems cartList)
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
               dal.PostToCart(cartList);
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex) 
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By Using this Method We Can Get List from The Cart
        /// </summary>
        /// <returns>It Returns List From Cart</returns>
        public List<CartItems> GetListFromCart() 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var pro = dal.GetListFromCart();
                return pro;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By Using This Method We can Delete Item From Cart
        /// </summary>
        /// <param name="id">By Using this Id we can Delete That Item  </param>
        public void DeleteItemFromCart(int id) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                dal.DeleteItemFromCart(id);
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By Using this Method We can UPDATE the Quantity of the Selected Product
        /// </summary>
        /// <param name="cartList">By using this cartList we can Update item Quantity </param>
        public void UpdateItemsById(CartItems cartList)
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                dal.UpdateItemsById(cartList);
            }
            //If SQLExeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw ex;
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// By Using this Method We can Get Product Details From DataBase
        /// </summary>
        /// <param name="id">By using this id we can GetProduct Details of the Item  </param>
        /// <returns>It Returns the cartList based on its Productid</returns>
        public CartItems GetProductItemById(int id) 
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var product = dal.GetProductItemById(id);
                return product;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By Using this Method We can Get UserName.
        /// </summary>
        /// <param name="name">UserName was Passed</param>
        /// <returns>It Return UserName </returns>
        public Login GetUserName(string name)
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var username = dal.GetUserName(name);
                return username;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
        /// <summary>
        /// By Using This Method We can Get Password.
        /// </summary>
        /// <param name="pwd">Password was Passed</param>
        /// <returns>Return Password</returns>
        public Login GetPassword(string pwd)
        {
            //Try Block,incase if code throws an Exception
            try
            {
                //Create Object For Data Layer
                OnlineShoppingSiteDataAccess dal = new OnlineShoppingSiteDataAccess();
                var password = dal.GetPassword(pwd);
                return password;
            }
            //If Exeption occurs then this blocks handles the Exception
            catch (OnlineShoppingSiteException ex)
            {
                throw new OnlineShoppingSiteException(ex.Message); 
            }
            //If any other Exeption occurs, then this blocks handles it
            catch (Exception ex)
            {
                throw new OnlineShoppingSiteException(ex.Message);
            }
        }
    }
}
